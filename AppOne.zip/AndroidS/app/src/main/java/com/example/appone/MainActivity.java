package com.example.appone;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;

import java.util.*;
import java.util.Scanner;

import android.util.Pair;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    private static Scanner sc;                                                        //объявление сканнера
    private static int step = 0;                                                      //нулевой шаг
    private static int max_steps = 9;                                                 //кол-во попыток по умолчанию
    private static int length = 4;                                                    //длина числа по умолчанию

    String[] val_spinner = {"-", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};     //набор значений для адаптеров spinner'ов
    private String[] spin_now_temp = {"-", "-", "-", "-"};  //память состояния выведенных в данный момент цифр на спиннерах
    int[] spins_id = {0, 0, 0, 0};        //массив id spinner'ов
    String spin_temp_warn = "";        //temp сообщение для TextView
    String spin_temp = "";             //temp значение выбранного элемента в spinner'e

    int pos_temp = 0;                  //temp значение позиции выбранного элемента в spinner'e
    int id_temp = 0;                   //temp значение id активированного spinner'a
    String message = "";               //сообщение для всплывающего уведомления TOAST
    int count_call_listener = 1;       //счетчик смены значений в спиннерах
    private String think_number;
    private String guessing_number;
    private int[] pos_temp_now = {0,0,0,0};



    //Определение спиннеров
    private Spinner spinner1;

    private Spinner spinner2;

    private Spinner spinner3;

    private Spinner spinner4;
    //private Spinner[] spinners = {spinner1,spinner2,spinner3,spinner4};
    private Spinner[] spinners = new Spinner[4];
    private Pair pair_num = new Pair (0,0);
    private Game game;
    private int count_press_check=-1;




    public void msg_to_text(){ //обнуление спиннеров
        runOnUiThread(() -> {
            spin_temp_warn="";
            for (int i = 0; i <= 3; i++) {
                //создание строки для последующего вывода значений спиннеров в "окно отладки"
                spin_temp_warn += spin_now_temp[i];
            }
            TextView check_out_warn = (TextView) findViewById(R.id.check_out_warn);
            check_out_warn.setText(spin_temp_warn);     //вывод памяти состояния spinner'ов на экран
        });
    }

    /*
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }

     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        spinner1 = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val_spinner);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val_spinner);
        spinner3 = (Spinner) findViewById(R.id.spinner3);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val_spinner);
        spinner4 = (Spinner) findViewById(R.id.spinner4);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, val_spinner);

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner1.setAdapter(adapter1);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner2.setAdapter(adapter2);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner3.setAdapter(adapter3);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner4.setAdapter(adapter4);

        Button press_check = (Button) findViewById(R.id.press_check);
        Button next_settings = (Button) findViewById(R.id.next_settings);

        //ArrayList<String> spin_name = new ArrayList<String>(Arrays.asList("spinner1", "spinner2", "spinner3", "spinner4"));
        spinners[0]=spinner1;
        spinners[1]=spinner2;
        spinners[2]=spinner3;
        spinners[3]=spinner4;

        for(int i=0; i<=3;i++){

            spins_id[i] =  spinners[i].getId();    //вбитие id идентификаторов spinner'ов в массив
        }
        /*
        spins_id[0] = spinner1.getId();   //вбитие id идентификаторов spinner'ов в массив
        spins_id[1] = spinner2.getId();
        spins_id[2] = spinner3.getId();
        spins_id[3] = spinner4.getId();
         */



        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();

                spin_temp_warn = "";      //сброс вывода памяти состояния
                spin_temp = "";           //
                pos_temp = position;      //temp память позиции в spinner'e
                id_temp = parent.getId();   //получение id вызванного spinner'a
                message = String.valueOf(id_temp);
                int char_temp;
                /*
                if (count_call_listener > 4) {
                    message = "Временно не используется" + count_call_listener;
                    Toast.makeText(getBaseContext(), message, Toast.LENGTH_SHORT).show();
                }
                count_call_listener += 1;   //сохранение в счетчик о произведенной итерации

                 */


                for(int i = 0; i<=3; i++){
                    spin_temp+=spin_now_temp[i];
                }

                char_temp = spin_temp.indexOf(item);
                if(char_temp>=0 && char_temp<=3){
                    spinners[char_temp].setSelection(0);
                }

                for (int i = 0; i <= 3; i++) {
                    //добавление значений спиннеров в память-массив
                    if (id_temp == spins_id[i]) {
                        spin_now_temp[i] = item;
                        pos_temp_now[i] = position;
                    }
                }
                msg_to_text();   //обновление мини-окна отладки
                spin_temp="";
                for(int i = 0; i<=3; i++){

                    spin_temp+=spin_now_temp[i];
                }
                guessing_number = spin_temp;
                if(guessing_number.contains("-"))
                    press_check.setEnabled(false);
                else
                    press_check.setEnabled(true);





            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };

        spinner1.setOnItemSelectedListener(itemSelectedListener);
        spinner2.setOnItemSelectedListener(itemSelectedListener);
        spinner3.setOnItemSelectedListener(itemSelectedListener);
        spinner4.setOnItemSelectedListener(itemSelectedListener);


        //блок ОСНОВНОЙ ИГРЫ:
        reset();
        new_game();

        TextInputEditText out_cows_found = findViewById(R.id.out_cows_found);   //указание блоков в XML
        TextInputEditText out_bulls_found = findViewById(R.id.out_bulls_found);
        TextInputEditText out_steps = findViewById(R.id.out_steps);
        TextView check_out_guess = findViewById(R.id.check_out_guess);
        TextView check_out_think = findViewById(R.id.check_out_think);




        //блок кнопки RESET
        Button press_reset = (Button) findViewById(R.id.press_reset);
        press_reset.setOnClickListener(view -> {    //действие при нажатии RESET
            reset();

        });


        //блок перезапуска игры - NEW GAME
        Button press_new_game = (Button) findViewById(R.id.press_new_game);
        press_new_game.setOnClickListener(view -> {
            new_game();
        });

        //блок кнопки CHECK

        press_check.setOnClickListener(view -> {
                check();
                check_out_think.setText(this.think_number);
                check_out_guess.setText(guessing_number);


        });


        //блок кнопки выхода в другое ACTIVITY
        /*
        next_settings.setOnClickListener(view -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);

        });

         */





        //блок выхода из игры
        {
        Button press_exit = (Button) findViewById(R.id.press_exit);
        press_exit.setOnClickListener(view -> finish());

        }



    }

    private void clear_spins(){
        runOnUiThread(new Thread(() -> {
            for (int i = 0; i <= 3; i++) {
                spin_now_temp[i] = "-";   //обнуление памяти состояния спиннеров
                spinners[i].setSelection(0);
            }
        }));

    }
    private void reset(){
        runOnUiThread(new Thread(() -> {
            TextInputEditText out_steps = findViewById(R.id.out_steps);

            msg_to_text();
            clear_spins();
            out_steps.setText(String.valueOf(count_press_check));
        }));

    }
    private void new_game(){
        runOnUiThread(new Thread(() -> {
            TextInputEditText out_cows_found = findViewById(R.id.out_cows_found);   //указание блоков в XML
            TextInputEditText out_bulls_found = findViewById(R.id.out_bulls_found);

            game = new Game();
            count_press_check=0;
            reset();
            out_bulls_found.setText(String.valueOf(pair_num.first));
            out_cows_found.setText(String.valueOf(pair_num.second));

        }));

    }
    private void check(){
        runOnUiThread(new Thread(() -> {
            TextInputEditText out_cows_found = findViewById(R.id.out_cows_found);   //указание блоков в XML
            TextInputEditText out_bulls_found = findViewById(R.id.out_bulls_found);
            TextInputEditText out_steps = findViewById(R.id.out_steps);

            count_press_check++;
            pair_num = this.game.checking_number(guessing_number);
            out_steps.setText(String.valueOf(count_press_check));
            out_bulls_found.setText(String.valueOf(pair_num.first));
            out_cows_found.setText(String.valueOf(pair_num.second));
        }));
    }
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        spin_now_temp = savedInstanceState.getStringArray("spin_now_temp");
        pos_temp_now = savedInstanceState.getIntArray("pos_temp_now");
        for (int i =0; i<3;i++){
            spinners[i].setSelection(pos_temp_now[i]);
        }

    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putStringArray("spin_now_temp", spin_now_temp);
        outState.putIntArray("pos_temp_now", pos_temp_now);


    }


}