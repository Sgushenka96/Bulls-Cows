package com.example.appone;
import android.util.Pair;

public class Game {
    private static int length_number = 4;
    private String think_number;


    public Game(){
        think_number = "";
        while(think_number.length()<length_number){
            int x = (int)(Math.random()*9);
            if(!think_number.contains(String.valueOf(x)))
                think_number+=String.valueOf(x);
        }
        think_number = think_number;

    }

     /*Генератор числа
    public String initialization(){
        think_number = "";
        while(think_number.length()<length_number){
            int x = (int)(Math.random()*9);
            if(!think_number.contains(String.valueOf(x)))
                think_number+=String.valueOf(x);
        }
        checking_number(spin_temp);
        return think_number;
    }
     */
     Pair<Integer,Integer> checking_number(String guessing_number){
        int cows = 0;
        int bulls = 0;
        for(int i = 0;i<think_number.length();i++){
            char c = think_number.charAt(i);
            int k = guessing_number.indexOf(c);
            if (k < 0)
                continue;
            if  (k == i)
                bulls++;
            else
                cows++;
        }
        return new Pair(bulls, cows);
        /*
        for(int i = 0; i<think_number_array.length-1; i++){

            for(int j =0; j<spin_now_temp.length-1; j++){
                if(spin_now_temp[j].equals(think_number_array[j])){
                    bulls++;    //нахождение одинаковых цифр на одинаковых позициях
                }
                else if(spin_now_temp[j].equals(think_number_array[i])){
                    cows++;     //нахождение похожих цифр на других позициях
                }
                else {
                    continue;
                }
            }
        }
        return (cows);

         */
    }
}
